<?php
$config = require 'settings.php';
$mysqli = new mysqli(
    $config['host'],
    $config['username'],
    $config['password'],
    $config['dbname']
);
if ($mysqli->connect_error) {
    error_log('Database connection failed: ' . $mysqli->connect_error);
    exit('Database connection error.');
}

if (!$mysqli->set_charset($config['charset'])) {
    error_log('Error loading character set ' . $config['charset'] . ': ' . $mysqli->error);
}
