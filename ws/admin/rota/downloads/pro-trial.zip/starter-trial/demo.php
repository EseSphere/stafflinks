<?php require_once('header-panel.php'); ?>

<section id="home" class="video-hero" style="height: 500px; background-image: url(images/cover_img_1.jpg);  background-size:cover; background-position: center center;background-attachment:fixed;" data-section="home">
	<div class="overlay"></div>
	<div class="display-t display-t2 text-center">
		<div class="display-tc display-tc2">
			<div class="container">
				<div class="col-md-12 col-md-offset-0">
					<div class="animate-box">
						<h2>Demo</h2>
						<p class="breadcrumbs"><span><a href="./">Home</a></span> <span>Demo</span></p>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

<div class="colorlib-work">
	<div class="container">
		<div class="row text-decoration-none text-center text-black">
			<a href="./starter-demo" class="text-decoration-none text-black">
				<div id="demo-box-effects" class="col-md-12 col-lg-12 col-sm-12 col-xl-12 mt-5">
					<div class="w-100 h-auto text-decoration-none text-center text-black">
						<img src="./images/demo/demo-1.png" id="img-effects" alt="Timeline Scheduling V1" />
					</div>
					<div style="margin-top: 40px;" class="w-100 h-auto text-decoration-none text-center text-black">
						<h2 class="mt-3">Timeline Scheduling V1</h2>
						<p class="text-muted text-left" style="border-left: 1px solid #ccc; border-right: 1px solid #ccc; padding:22px;">
							Our Staff Scheduling Timeline Tool provides a real-time, zoomable 24-hour view with color-coded rows and smart layering to avoid conflicts.
							Easily search, filter, and load schedules by name, city, or department—no page reloads required, with tooltips and click-to-view details.
							Enjoy mobile-friendly design, light/dark modes, synced scrolling, and secure planning with auto-saved preferences and right-click protection.
						</p>
						<a style="margin-top: -50px;" href="./starter-demo" class="btn btn-lg btn-info text-decoration-none">Read More...</a>
					</div>
				</div>
			</a>

			<a href="./pro-demo" class="text-decoration-none text-black mt-5">
				<div id="demo-box-effects" class="col-md-12 col-lg-12 col-sm-12 col-xl-12 mt-5">
					<div class="w-100 h-auto text-decoration-none text-center text-black">
						<img src="./images/demo/demo-2.png" id="img-effects" alt="Timeline Scheduling V2" />
					</div>
					<div style="margin-top: 40px;" class="w-100 h-auto text-decoration-none text-center text-black">
						<h2 class="mt-3">Timeline Scheduling V2</h2>
						<p class="text-muted text-left" style="border-left: 1px solid #ccc; border-right: 1px solid #ccc; padding:22px;">
							Our Staff Scheduling Timeline Tool provides a real-time, zoomable 24-hour view with color-coded rows and smart conflict avoidance.
							Easily search, filter by name, city, or department, and instantly load schedules without page reloads—hover for tooltips, click for details.
							Enjoy mobile-friendly design, light/dark mode, synced scrolling, grouped events, and auto-saved preferences for efficient, secure planning.
						</p>
						<a style="margin-top: -50px;" href="./pro-demo" class="btn btn-lg btn-info text-decoration-none">Read More...</a>
					</div>
				</div>
			</a>
		</div>
	</div>
</div>

<?php require_once('footer-panel.php'); ?>