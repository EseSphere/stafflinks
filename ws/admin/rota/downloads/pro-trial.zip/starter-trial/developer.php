<?php require_once('header-panel.php'); ?>

<section id="home" class="video-hero" style="height: 500px; background-image: url(images/cover_img_1.jpg);  background-size:cover; background-position: center center;background-attachment:fixed;" data-section="home">
    <div class="overlay"></div>
    <div class="display-t display-t2 text-center">
        <div class="display-tc display-tc2">
            <div class="container">
                <div class="col-md-12 col-md-offset-0">
                    <div class="animate-box">
                        <h2>Developer</h2>
                        <p class="breadcrumbs"><span><a href="./">Home</a></span> <span>Developer</span></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<div class="colorlib-work">
    <div class="container">
        <div class="row row-pb-lg">
            <div class="col-md-6 animate-box">
                <div class="video colorlib-video" style="background-image: url(./images/webdesign.png);">
                </div>
            </div>
            <div class="col-md-6 animate-box">
                <br>
                <h2>Customizable Code Solutions Tailored to Your Needs</h2>
                <p>At Staff Scroll, we empower developers with a fully customizable scheduling platform built using modern web technologies. Our modular approach allows you to easily adapt and extend each part of the system to suit your specific requirements. Designed to be very easy to use and integrate, our code is straightforward and well-structured, making it simple for developers of all skill levels to understand and implement quickly into your existing projects.</p>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row text-decoration-none text-center text-black">
            <div class="col-md-4 text-center animate-box">
                <div class="services">
                    <div class="desc">
                        <h3>HTML: Structured and Semantic Markup</h3>
                        <p>Clean, semantic HTML templates provide the foundation for accessible, SEO-friendly scheduling interfaces that are easy to customize for branding and workflow needs.</p>
                        <pre><code>&lt;div class="timeline-event" data-start="09:00" data-end="11:00"&gt; &lt;h4&gt;Morning Shift&lt;/h4&gt; &lt;/div&gt;</code></pre>
                    </div>
                </div>
            </div>

            <!-- CSS -->
            <div class="col-md-4 text-center animate-box">
                <div class="services">
                    <div class="desc">
                        <h3>CSS: Flexible Styling and Responsive Design</h3>
                        <p>Our modular CSS enables quick theme customization, responsive layouts, and light/dark mode toggles to ensure your schedule looks great on all devices.</p>
                        <pre><code>.timeline-event { background-color: #3498db; color: white; border-radius: 4px; padding: 8px;}</code></pre>
                    </div>
                </div>
            </div>

            <!-- PHP & MySQL -->
            <div class="col-md-4 text-center animate-box">
                <div class="services">
                    <div class="desc">
                        <h3>PHP &amp; MySQL: Robust Backend Management</h3>
                        <p>Powerful server-side logic and scalable data storage handle user authentication, event management, and conflict resolution with easy integration and customization options.</p>
                        <pre><code>&lt;?php // Fetch events for a staff member $sql = "SELECT * FROM events WHERE staff_id = ?"; $stmt = $pdo->prepare($sql); $stmt->execute([$staff_id]); $events = $stmt->fetchAll();?&gt;</code></pre>
                    </div>
                </div>
            </div>
        </div>

        <div class="row" style="margin-top: 30px;">
            <!-- JavaScript -->
            <div class="col-md-4 text-center animate-box">
                <div class="services">
                    <div class="desc">
                        <h3>JavaScript: Dynamic, Interactive Frontend</h3>
                        <p>Deliver smooth real-time interactions with draggable, resizable events, tooltips, and popups powered by modular, event-driven JavaScript code.</p>
                        <pre><code>eventElement.addEventListener('dragend', (e) =&gt; {updateEventTime(e.target.dataset.id, e.target.style.left);});</code></pre>
                    </div>
                </div>
            </div>

            <!-- Scalability & Integration -->
            <div class="col-md-4 text-center animate-box">
                <div class="services">
                    <div class="desc">
                        <h3>Scalable &amp; Integratable</h3>
                        <p>Designed to grow with your business, Staff Scroll’s code easily integrates with HR, payroll, and other systems, ensuring seamless workflow management.</p>
                        <pre><code>// Example: API call to sync events with external payroll systemfetch('/api/syncEvents', {method: 'POST', body: JSON.stringify(eventsData), headers: { 'Content-Type': 'application/json' }});</code></pre>
                    </div>
                </div>
            </div>

            <!-- Developer Friendly -->
            <div class="col-md-4 text-center animate-box">
                <div class="services">
                    <div class="desc">
                        <h3>Developer-Friendly &amp; Flexible</h3>
                        <p>Clear documentation and modular code empower your team to customize UI, backend logic, and features without limitations—giving you full control over your scheduling system.</p>
                        <pre><code>// Modular utility example: Time formatting function formatTime(decimalTime) {const hours = Math.floor(decimalTime); const minutes = Math.round((decimalTime - hours) * 60);return `${hours.toString().padStart(2,'0')}:${minutes.toString().padStart(2,'0')}`;}</code></pre>
                    </div>
                </div>
            </div>
        </div>
        <div class="row" style="margin-top: 30px;">
            <div class="col-md-12 text-center animate-box">
                <div class="services">
                    <div class="desc">
                        <h3>Get Started with Staff Scroll Today!</h3>
                        <p>Ready to take your scheduling to the next level? Contact us to learn more about our developer-friendly solutions and how we can help you build the perfect scheduling system for your needs.</p>
                        <a href="./contact" class="btn btn-lg btn-info text-decoration-none">Contact Us</a>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <?php require_once('footer-panel.php'); ?>